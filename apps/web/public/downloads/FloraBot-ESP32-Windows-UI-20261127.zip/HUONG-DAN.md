# Nạp ESP32 cho tủ FloraBot

## Trên web Technician

1. Mở **Lắp đặt kiosk**, chọn phiếu được giao và mở **Cấu hình ESP32** → **Nạp qua USB**.
2. Xác thực bằng mật khẩu tài khoản hiện tại. Cắm ESP32 bằng cáp USB có dữ liệu, đối chiếu tủ và nhập Wi-Fi tại nơi lắp.
3. Bật **Nạp cả firmware lần đầu hoặc khi đổi phiên bản** nếu bo mới hoặc cần nâng firmware. Với bo đã chạy đúng bản này, bỏ chọn để chỉ ghi cấu hình.
4. Bấm **Chọn cổng USB và nạp**. Đợi thông báo ghi USB, kiểm tra journal và nhận tín hiệu mới từ tủ.

Dùng Chrome hoặc Edge trên Windows. Khi quyền trên phiếu thay đổi trước lúc ghi, trang dừng thao tác. File cấu hình được đọc trong bộ nhớ của trang. Khi trình duyệt thiếu Web Serial, dùng app Windows bên dưới.

## App Windows

1. Giải nén ZIP, chạy **FloraBot-ESP32.exe**. App dùng cổng COM trực tiếp và đã có firmware bên trong.
2. Trong phiếu lắp đặt, chọn **Tải cấu hình ESP32** rồi xác thực để nhận file riêng của tủ. Chọn file **config.local.h** trong app và đối chiếu Hardware ID.
3. Cắm bo, chọn cổng COM và nhập Wi-Fi. Mục nạp cả firmware dùng cho bo mới hoặc khi đổi bản. Bấm **Nạp ESP32** và giữ cáp kết nối đến khi app báo kết quả.
   Nếu bo đã có cấu hình của tủ khác, app hiện mã tủ cũ và mã tủ mới. Chọn Yes để chuyển bo sau khi đối chiếu cả hai mã. Chọn No để dừng trước khi ghi.
4. Sau khi app báo ghi và kiểm tra journal thành công, mở web để kiểm tra tủ Online và xác nhận heartbeat. Nếu Windows chưa hiện cổng COM, thử cáp USB có dữ liệu và kiểm tra driver USB-to-serial của bo.

File cấu hình đã tải chứa khóa của đúng tủ. Giữ file trên máy kỹ thuật được cấp quyền và dọn theo quy trình của đội sau khi dùng. ZIP chỉ có công cụ và firmware dùng chung.

## Build và phát hành

Chạy ở thư mục gốc repo IoT trên máy build. Lệnh đầu build firmware, kiểm tra phân vùng và xuất cùng một manifest cho các công cụ nạp.

```powershell
python -m platformio run -e esp32dev-provisioning
python test/verify_partitions.py .pio/build/esp32dev-provisioning
node tools/provision/build.mjs --firmware-only
```

Trong môi trường Docker, có thể xuất tệp bằng lệnh dưới. Bản build từ môi trường khác có thể cho hash firmware khác. Dùng cùng một thư mục release đã được duyệt cho app Windows và dịch vụ. Nếu đang phục vụ tủ đã nạp bản thực địa, chọn lại bộ binary đã dùng cho tủ đó.

```powershell
docker build --target provisioning-artifacts --output type=local,dest=.pio/provision/firmware .
```

Build app Windows từ môi trường Python 3.12 có Tk. Bản Windows release được đóng bằng esptool 5.4.0 và PyInstaller 6.22.3.

```powershell
python -m venv .pio/desktop-env
& .pio/desktop-env/Scripts/python.exe -m pip install esptool==5.4.0 pyinstaller==6.22.3
& .pio/desktop-env/Scripts/python.exe test/desktop_provisioning.py
$bundle = (Resolve-Path -LiteralPath '.pio/provision/firmware').Path
& .pio/desktop-env/Scripts/python.exe -m PyInstaller --noconfirm --onefile --windowed --name FloraBot-ESP32 --collect-data esptool --add-data "${bundle}:firmware" --distpath .pio/desktop-dist --workpath .pio/desktop-work --specpath .pio tools/provision/desktop.py
```

Build dịch vụ độc lập từ bộ firmware đã chọn. Dịch vụ kiểm tra checksum khi khởi động, chỉ phục vụ manifest và bốn binary theo release, và không cần PostgreSQL, MQTT hoặc thư viện Arduino khi chạy.

```powershell
docker build -f tools/provision/Dockerfile --build-context release=.pio/provision/firmware -t florabot-firmware:esp32-classic-runtime-v1 .
docker run -d --restart unless-stopped --name florabot-firmware --env FLORABOT_FIRMWARE_TOKEN -p 127.0.0.1:8780:8780 florabot-firmware:esp32-classic-runtime-v1
```

Cấp `FLORABOT_FIRMWARE_TOKEN` từ cấu hình riêng của dịch vụ trước khi chạy. `GET /health` trả mã phiên bản. `GET /v1/firmware/esp32-classic-runtime-v1/manifest.json` và bốn binary yêu cầu Bearer token. Nếu chạy trực tiếp bằng Python, đặt `FLORABOT_FIRMWARE_DIR` trỏ vào thư mục firmware rồi chạy `python tools/provision/release_server.py`.

Khi đưa lên môi trường thực, dùng một endpoint HTTPS tới dịch vụ và cấu hình `FLORABOT_FIRMWARE_RELEASE_URL` (URL đầy đủ của thư mục release) cùng `FLORABOT_FIRMWARE_TOKEN` ở phía server của FE. FE chỉ nhận file cấu hình riêng qua endpoint BE hiện có trên phiếu, với xác thực lại. Web cần BE hỗ trợ trường `lastHeartbeatAt` để xác nhận kết nối sau khi nạp. BE dùng cột đã có sẵn trong PostgreSQL.

Giữ nguyên bundle của bản đã phát hành. Khi nâng firmware, build release tên mới, dùng đúng bundle đó để build lại app, kiểm tra một bo rồi đổi URL của FE sang release mới. Để quay lại phía web, trỏ URL về release cũ. Tủ đã nạp firmware mới chỉ có thể nạp cấu hình-only bằng manifest tương ứng với firmware trên bo.
