import hashlib
import json
from pathlib import Path

FILES = {
    "bootloader.bin": (0x1000, 0x8000),
    "partitions.bin": (0x8000, 0x9000),
    "boot_app0.bin": (0xE000, 0x10000),
    "firmware.bin": (0x10000, 0x310000),
}


def read_bundle(directory: Path):
    manifest_bytes = (directory / "manifest.json").read_bytes()
    if len(manifest_bytes) > 16 * 1024:
        raise ValueError("Firmware manifest exceeds 16 KB")
    manifest = json.loads(manifest_bytes)
    if not isinstance(manifest, list) or len(manifest) != len(FILES):
        raise ValueError("Unexpected firmware manifest")
    entries = {item["name"]: item for item in manifest}
    if set(entries) != set(FILES):
        raise ValueError("Unexpected firmware components")

    files = {"manifest.json": manifest_bytes}
    for name, (address, limit) in FILES.items():
        entry = entries[name]
        data = (directory / name).read_bytes()
        end = address + ((len(data) + 4095) // 4096) * 4096
        if (not data or entry["address"] != address or entry["size"] != len(data) or end > limit
                or entry["sha256"] != hashlib.sha256(data).hexdigest()
                or entry["md5"] != hashlib.md5(data).hexdigest()):
            raise ValueError("Firmware checksum or flash range mismatch for " + name)
        files[name] = data
    return entries, files
