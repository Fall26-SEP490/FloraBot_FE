import hashlib
import json
import os
from pathlib import Path
import queue
import re
import struct
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from esptool import cmds
from serial.tools.list_ports import comports

from firmware_bundle import FILES, read_bundle

JOURNAL_START = 0x310000
JOURNAL_SIZE = 0x20000
CONFIG_START = 0x330000
CONFIG_SIZE = 0x8000
FIELDS = {
    "hardwareId": 64, "wifiSsid": 32, "wifiPassword": 64, "mqttHost": 253,
    "mqttPassword": 256, "hmacKeyHex": 64, "caCertificate": 4096,
}
HEADER_KEYS = ("hardwareId", "mqttHost", "mqttPassword", "hmacKeyHex", "caCertificate")


def parse_header(text):
    text = '\n'.join(text.splitlines())
    values = {}
    for key in HEADER_KEYS:
        matches = re.findall(
            rf'^[ \t]*inline constexpr char {key}\[\] = "((?:[^"\\\r\n]|\\[0-7]{{3}})*)";[ \t]*$',
            text, re.M,
        )
        if len(matches) != 1:
            raise ValueError("File cấu hình thiếu hoặc lặp trường " + key + ".")
        values[key] = bytes(
            int(octal, 8) if octal else ord(char)
            for octal, char in re.findall(r"\\([0-7]{3})|([^\\])", matches[0])
        ).decode("utf-8")
    ports = re.findall(r"^[ \t]*inline constexpr uint16_t mqttPort = ([0-9]{1,5});[ \t]*$", text, re.M)
    if len(ports) != 1:
        raise ValueError("File cấu hình thiếu hoặc lặp cổng MQTT.")
    values["mqttPort"] = int(ports[0])
    return values


def configuration_image(fields, ssid, wifi_password):
    values = dict(fields, wifiSsid=ssid, wifiPassword=wifi_password)
    config = {"version": 1}
    for key, maximum in FIELDS.items():
        if key == "mqttPassword":
            config["mqttPort"] = values["mqttPort"]
        value = values[key]
        if (not value and key != "wifiPassword") or "\x00" in value or len(value.encode()) > maximum:
            raise ValueError("Kiểm tra lại trường " + key + ".")
        config[key] = value
    if not re.fullmatch(r"[a-zA-Z0-9_-]+", config["hardwareId"]):
        raise ValueError("Mã thiết bị chỉ nhận chữ, số, gạch ngang và gạch dưới.")
    if not re.fullmatch(r"[a-zA-Z0-9.-]+", config["mqttHost"]) or not 1 <= config["mqttPort"] <= 65535:
        raise ValueError("Địa chỉ hoặc cổng MQTT không hợp lệ.")
    if not re.fullmatch(r"[a-fA-F0-9]{64}", config["hmacKeyHex"]):
        raise ValueError("Khóa HMAC phải có đúng 64 ký tự hex.")
    if not re.fullmatch(r"-----BEGIN CERTIFICATE-----[\s\S]+-----END CERTIFICATE-----\s*", config["caCertificate"]):
        raise ValueError("Chứng chỉ CA cần ở định dạng PEM.")
    payload = json.dumps(config, ensure_ascii=False, separators=(",", ":")).encode()
    if len(payload) > 8192:
        raise ValueError("Cấu hình thiết bị vượt kích thước cho phép.")
    return (b"FBC1" + struct.pack("<I", len(payload)) + hashlib.sha256(payload).digest() + payload).ljust(
        CONFIG_SIZE, b"\xff"
    )


def ensure_same_kiosk(data, expected, confirm_transfer=None):
    if data[:4] != b"FBC1":
        return
    length = struct.unpack_from("<I", data, 4)[0]
    payload = data[40:40 + length]
    if not 0 < length <= 8192 or hashlib.sha256(payload).digest() != data[8:40]:
        raise ValueError("Cấu hình đang có trên bo bị lỗi. Liên hệ phụ trách kỹ thuật trước khi nạp.")
    config = json.loads(payload)
    current = config.get("hardwareId") if isinstance(config, dict) else None
    if not isinstance(current, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", current):
        raise ValueError("Mã thiết bị đang lưu trên bo không hợp lệ.")
    if current != expected and not (confirm_transfer and confirm_transfer(current, expected)):
        raise ValueError("Bo đang có cấu hình của tủ khác. Đã dừng trước khi ghi flash.")


def verify_firmware(esp, entries, names):
    for name in names:
        entry = entries[name]
        if esp.flash_md5sum(entry["address"], entry["size"]).lower() != entry["md5"]:
            raise ValueError("Firmware trên bo chưa khớp gói này. Kiểm tra bo và chế độ nạp.")


def flash(port, hardware_id, image, install_firmware, bundle, report, confirm_transfer=None):
    entries, files = bundle
    report("Đang kết nối với ESP32…")
    esp = cmds.connect_esp(port=port, connect_attempts=3)
    try:
        if esp.CHIP_NAME != "ESP32":
            raise ValueError("Chỉ hỗ trợ ESP32 cổ điển.")
        esp = cmds.run_stub(esp)
        cmds.attach_flash(esp)
        size = re.fullmatch(r"(\d+)MB(?:-c1)?", cmds.detect_flash_size(esp) or "")
        if not size or int(size[1]) < 4:
            raise ValueError("Bo phải có bộ nhớ flash ít nhất 4 MB.")
        ensure_same_kiosk(cmds.read_flash(esp, CONFIG_START, CONFIG_SIZE, no_progress=True), hardware_id, confirm_transfer)
        if not install_firmware:
            verify_firmware(esp, entries, ("partitions.bin", "firmware.bin"))
        before = esp.flash_md5sum(JOURNAL_START, JOURNAL_SIZE)
        if not re.fullmatch(r"[a-fA-F0-9]{32}", before):
            raise ValueError("Không đọc được checksum journal.")
        report("Đang nạp và kiểm tra lại qua USB…")
        images = [(address, files[name]) for name, (address, _) in FILES.items()] if install_firmware else []
        images.append((CONFIG_START, image))
        cmds.write_flash(esp, images, compress=True, no_progress=True)
        if install_firmware:
            verify_firmware(esp, entries, FILES)
        if cmds.read_flash(esp, CONFIG_START, CONFIG_SIZE, no_progress=True) != image:
            raise ValueError("Cấu hình đọc lại từ ESP32 sai checksum.")
        if before.lower() != esp.flash_md5sum(JOURNAL_START, JOURNAL_SIZE).lower():
            raise ValueError("Checksum journal đã thay đổi. Báo phụ trách kỹ thuật để kiểm tra.")
        cmds.reset_chip(esp)
    finally:
        esp._port.close()


def bundle_path():
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "firmware"
    return Path(__file__).resolve().parents[2] / ".pio" / "provision" / "firmware"


class ProvisioningApp(ttk.Frame):
    COLORS = {
        "page": "#F1F5EF", "card": "#FFFFFF", "line": "#DCE6DC",
        "ink": "#173525", "muted": "#526B5D", "green": "#20563C",
        "rail": "#122F24", "rail_line": "#355447", "rail_muted": "#B6C9BD",
        "leaf": "#BFDFAC", "soft": "#EEF5EB",
    }
    FONT = "Segoe UI"

    def __init__(self, root, bundle):
        self.configure_theme(root)
        super().__init__(root, style="Desk.TFrame")
        self.pack(fill="both", expand=True)
        self.bundle = bundle
        self.messages = queue.Queue()
        self.fields = None
        self.running = False
        self.tone = "idle"
        self.status = tk.StringVar(value="Chọn tệp cấu hình đã tải từ phiếu lắp đặt.")
        self.status_title = tk.StringVar(value="Chờ cấu hình")
        self.device = tk.StringVar(value="Chưa chọn tệp")
        self.device_hint = tk.StringVar(value="Chọn config.local.h của đúng tủ cần nạp.")
        self.network = tk.StringVar()
        self.install = tk.BooleanVar()

        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self.build_sidebar()
        self.build_form()
        self.network.trace_add("write", lambda *_: self.refresh_form())
        self.port.bind("<<ComboboxSelected>>", lambda _: self.refresh_form())
        self.refresh_ports()
        self.pick.focus_set()
        root.protocol("WM_DELETE_WINDOW", lambda: None if self.running else root.destroy())
        self.after(120, self.poll)

    @classmethod
    def configure_theme(cls, root):
        colors = cls.COLORS
        style = ttk.Style(root)
        style.theme_use("clam")
        style.configure(".", font=(cls.FONT, 10), foreground=colors["ink"], background=colors["page"])
        style.configure("Desk.TFrame", background=colors["page"])
        style.configure("Card.TFrame", background=colors["card"])
        style.configure("Field.TEntry", fieldbackground="#F8FAF7", padding=(10, 7),
                        foreground=colors["ink"], insertcolor=colors["ink"],
                        bordercolor=colors["line"], lightcolor=colors["line"], darkcolor=colors["line"])
        style.configure("Field.TCombobox", fieldbackground="#F8FAF7", background="#EDF4EA",
                        padding=(9, 6), bordercolor=colors["line"], lightcolor=colors["line"],
                        darkcolor=colors["line"], arrowcolor=colors["green"], arrowsize=13)
        for name in ("Field.TEntry", "Field.TCombobox"):
            style.map(name, bordercolor=[("focus", "#56866C")],
                      fieldbackground=[("disabled", "#EFF3EF"), ("readonly", "#F8FAF7")],
                      foreground=[("disabled", "#6D8074")])
        root.option_add("*TCombobox*Listbox.font", (cls.FONT, 10))
        root.option_add("*TCombobox*Listbox.selectBackground", colors["green"])
        root.option_add("*TCombobox*Listbox.selectForeground", "#FFFFFF")

        style.configure("Quiet.TButton", background=colors["soft"], bordercolor="#CDDECD",
                        darkcolor=colors["soft"], lightcolor=colors["soft"], padding=(13, 7),
                        foreground=colors["green"], font=(cls.FONT, 10, "bold"), relief="flat")
        style.map("Quiet.TButton",
                  background=[("disabled", "#EDF1EC"), ("pressed", "#D9E8D6"), ("active", "#E4F0DF")],
                  foreground=[("disabled", "#77877C")], bordercolor=[("focus", "#4A7C5D")])
        style.configure("Action.TButton", background=colors["green"], foreground="#FFFFFF",
                        darkcolor=colors["green"], lightcolor=colors["green"], bordercolor=colors["green"],
                        font=(cls.FONT, 11, "bold"), padding=(20, 11), relief="flat")
        style.map("Action.TButton",
                  background=[("disabled", "#D6E5D9"), ("pressed", "#123C28"), ("active", "#2B6B4A")],
                  foreground=[("disabled", "#476356")],
                  bordercolor=[("focus", "#7DAD8C")])
        style.configure("Mode.TCheckbutton", background=colors["soft"],
                        foreground=colors["ink"], font=(cls.FONT, 10, "bold"),
                        indicatorbackground=colors["card"], indicatormargin=(0, 0, 8, 0))
        style.map("Mode.TCheckbutton",
                  background=[("active", colors["soft"])],
                  indicatorbackground=[("selected", colors["green"])],
                  foreground=[("disabled", "#6D8074")])
        style.configure("Activity.Horizontal.TProgressbar", thickness=5, borderwidth=0,
                        troughcolor="#E4EDE3", background="#538B65", lightcolor="#538B65",
                        darkcolor="#538B65")

    def label(self, parent, text=None, *, size=10, bold=False, color=None, **options):
        return tk.Label(parent, text=text, font=(self.FONT, size, "bold" if bold else "normal"),
                        bg=parent.cget("bg"), fg=color or self.COLORS["ink"],
                        anchor="w", justify="left", borderwidth=0, **options)

    def build_sidebar(self):
        colors = self.COLORS
        rail = tk.Frame(self, bg=colors["rail"], width=235)
        rail.grid(row=0, column=0, sticky="ns")
        rail.grid_propagate(False)
        rail.grid_columnconfigure(0, weight=1)
        rail.grid_rowconfigure(3, weight=1)

        brand = tk.Frame(rail, bg=colors["rail"])
        brand.grid(row=0, column=0, sticky="ew", padx=23, pady=(28, 25))
        mark = tk.Canvas(brand, width=43, height=43, bg=colors["rail"], highlightthickness=0)
        mark.pack(side="left")
        mark.create_oval(1, 1, 42, 42, fill="#28513A", outline="")
        mark.create_oval(12, 12, 23, 22, fill=colors["leaf"], outline="")
        mark.create_oval(20, 10, 31, 24, fill="#DFEDCA", outline="")
        mark.create_oval(17, 19, 28, 29, fill="#A9CD93", outline="")
        mark.create_line(21, 34, 23, 23, fill="#DFEDCA", width=2)
        words = tk.Frame(brand, bg=colors["rail"])
        words.pack(side="left", padx=(10, 0))
        self.label(words, "FloraBot", size=16, bold=True, color="#F7F9F3").pack(anchor="w")
        self.label(words, "Công cụ kỹ thuật viên", size=9, color=colors["rail_muted"]).pack(anchor="w")

        tk.Frame(rail, bg=colors["rail_line"], height=1).grid(row=1, column=0, sticky="ew", padx=24)
        flow = tk.Frame(rail, bg=colors["rail"])
        flow.grid(row=2, column=0, sticky="ew", padx=24, pady=(27, 0))
        self.label(flow, "Quy trình nạp", size=11, bold=True, color="#F5F9F1").pack(anchor="w", pady=(0, 15))
        self.steps = []
        for number, name in enumerate(("Cấu hình tủ", "USB và Wi-Fi", "Nạp và kiểm tra"), start=1):
            step = tk.Frame(flow, bg=colors["rail"])
            step.pack(fill="x", pady=(0, 11))
            index = self.label(step, str(number), size=10, bold=True, color=colors["rail_muted"], width=2)
            index.configure(anchor="center", padx=4, pady=5, bg="#234537")
            index.pack(side="left")
            label = self.label(step, name, color=colors["rail_muted"])
            label.pack(side="left", padx=(11, 0))
            self.steps.append((number, index, label))

        note = tk.Frame(rail, bg="#1B3C2E")
        note.grid(row=4, column=0, sticky="ew", padx=18, pady=(18, 24))
        self.label(note, "Cáp USB dữ liệu", size=10, bold=True, color=colors["leaf"]).pack(
            anchor="w", padx=12, pady=(10, 3)
        )
        self.label(note, "Giữ cáp kết nối đến khi app báo kết quả.", size=9, color="#D7E6D8",
                   wraplength=165).pack(anchor="w", padx=12, pady=(0, 11))

    def card(self, parent, row):
        card = tk.Frame(parent, bg=self.COLORS["card"], highlightbackground=self.COLORS["line"],
                        highlightcolor=self.COLORS["line"], highlightthickness=1, padx=16, pady=12)
        card.grid(row=row, column=0, sticky="ew", pady=(0, 12))
        card.columnconfigure(0, weight=1)
        return card

    def build_form(self):
        colors = self.COLORS
        content = tk.Frame(self, bg=colors["page"], padx=28, pady=20)
        content.grid(row=0, column=1, sticky="nsew")
        content.columnconfigure(0, weight=1)
        content.rowconfigure(3, weight=1)
        header = tk.Frame(content, bg=colors["page"])
        header.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        self.label(header, "Nạp ESP32 qua USB", size=23, bold=True).pack(anchor="w")
        self.label(header, "Cấu hình tủ hoa FloraBot trực tiếp từ máy kỹ thuật viên.",
                   color=colors["muted"]).pack(anchor="w", pady=(3, 0))

        config = self.card(content, 1)
        self.label(config, "Cấu hình tủ", size=13, bold=True).grid(row=0, column=0, columnspan=2, sticky="w")
        preview = tk.Frame(config, bg=colors["soft"], padx=11, pady=7)
        preview.grid(row=1, column=0, sticky="ew", padx=(0, 10), pady=(8, 0))
        self.label(preview, textvariable=self.device, bold=True, wraplength=355).pack(anchor="w")
        self.label(preview, textvariable=self.device_hint, size=9, color=colors["muted"],
                   wraplength=355).pack(anchor="w", pady=(1, 0))
        self.pick = ttk.Button(config, text="Chọn tệp .h", style="Quiet.TButton", command=self.choose_file)
        self.pick.grid(row=1, column=1, sticky="e", pady=(8, 0))

        connection = self.card(content, 2)
        self.label(connection, "Kết nối USB và Wi-Fi", size=13, bold=True).pack(anchor="w", pady=(0, 8))
        self.label(connection, "Cổng USB", bold=True).pack(anchor="w", pady=(0, 3))
        usb = tk.Frame(connection, bg=colors["card"])
        usb.pack(fill="x")
        self.port = ttk.Combobox(usb, state="readonly", style="Field.TCombobox")
        self.port.pack(side="left", fill="x", expand=True)
        self.scan = ttk.Button(usb, text="Tìm lại cổng", style="Quiet.TButton", command=self.refresh_ports)
        self.scan.pack(side="left", padx=(8, 0))

        wifi = tk.Frame(connection, bg=colors["card"])
        wifi.pack(fill="x", pady=(9, 11))
        wifi.columnconfigure((0, 1), weight=1, uniform="wifi")
        self.ssid = self.entry(wifi, "Tên Wi-Fi", 0, textvariable=self.network)
        self.password = self.entry(wifi, "Mật khẩu Wi-Fi", 1, show="•")
        mode = tk.Frame(connection, bg=colors["soft"], padx=10, pady=7)
        mode.pack(fill="x")
        self.include_firmware = ttk.Checkbutton(
            mode, variable=self.install, text="Nạp cả firmware", style="Mode.TCheckbutton",
        )
        self.include_firmware.pack(anchor="w")
        self.label(mode, "Chọn khi nạp bo mới hoặc đổi phiên bản firmware.", size=9,
                   color=colors["muted"]).pack(anchor="w", padx=(23, 0))

        dock = self.card(content, 4)
        details = tk.Frame(dock, bg=colors["card"])
        details.grid(row=0, column=0, sticky="nsew", padx=(0, 13))
        top = tk.Frame(details, bg=colors["card"])
        top.pack(fill="x")
        self.status_dot = tk.Canvas(top, width=12, height=16, bg=colors["card"], highlightthickness=0)
        self.status_dot.pack(side="left", padx=(0, 6))
        self.dot = self.status_dot.create_oval(2, 5, 9, 12, fill="#769480", outline="")
        self.status_caption = self.label(top, textvariable=self.status_title, bold=True)
        self.status_caption.pack(side="left", anchor="w")
        message = self.label(details, textvariable=self.status, size=9, color=colors["muted"],
                             wraplength=350)
        message.pack(fill="x", pady=(3, 0))

        self.start = ttk.Button(dock, text="Nạp ESP32", style="Action.TButton", command=self.start_flash)
        self.start.grid(row=0, column=1, sticky="e")
        self.progress = ttk.Progressbar(dock, mode="indeterminate", style="Activity.Horizontal.TProgressbar")
        self.progress.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(9, 0))
        self.progress.grid_remove()

    def entry(self, parent, label, column, **options):
        field = tk.Frame(parent, bg=self.COLORS["card"])
        field.grid(row=0, column=column, sticky="ew", padx=(0, 8) if column == 0 else (8, 0))
        self.label(field, label, bold=True).pack(anchor="w", pady=(0, 3))
        entry = ttk.Entry(field, style="Field.TEntry", **options)
        entry.pack(fill="x")
        return entry

    def refresh_form(self):
        if self.tone in ("idle", "success") and self.fields and self.port.get() and self.network.get():
            self.set_status("idle", "Đối chiếu mã tủ và cổng USB trước khi nạp.", "Sẵn sàng nạp")
        elif self.status_title.get() == "Sẵn sàng nạp":
            self.set_status("idle", "Chọn cổng USB và nhập tên Wi-Fi trước khi nạp.")
        else:
            self.refresh_steps()

    def refresh_steps(self):
        count = int(self.fields is not None)
        if count and self.port.get() and self.network.get():
            count = 2
        if self.tone == "success":
            count = 3
        for number, index, label in self.steps:
            complete = number <= count
            active = number == count + 1
            index.configure(text="✓" if complete else str(number),
                            bg=self.COLORS["leaf"] if complete or active else "#234537",
                            fg=self.COLORS["rail"] if complete or active else self.COLORS["rail_muted"])
            label.configure(fg="#F6F9F3" if complete or active else self.COLORS["rail_muted"])

    def set_status(self, tone, message, title=None):
        self.tone = tone
        heading, color = {
            "idle": ("Chờ thao tác", "#688673"),
            "active": ("Đang nạp", "#2F7A52"),
            "success": ("Đã nạp xong", "#26704C"),
            "error": ("Cần kiểm tra", "#A04C2B"),
        }[tone]
        self.status_title.set(title or heading)
        self.status.set(message)
        self.status_caption.configure(fg=color)
        self.status_dot.itemconfigure(self.dot, fill=color)
        self.refresh_steps()

    def choose_file(self):
        path = filedialog.askopenfilename(filetypes=[("Cấu hình ESP32", "*.h")])
        if not path:
            return
        self.fields = None
        self.device.set("Chưa chọn tệp")
        self.device_hint.set("Chọn config.local.h của đúng tủ cần nạp.")
        try:
            with open(path, "rb") as file:
                header = file.read(16 * 1024 + 1)
            if len(header) > 16 * 1024:
                raise ValueError("File cấu hình vượt kích thước cho phép.")
            self.fields = parse_header(header.decode("utf-8-sig"))
        except (OSError, ValueError):
            self.set_status("error", "Tệp không đúng định dạng. Tải lại config.local.h từ phiếu lắp đặt.")
            return
        self.device.set("Mã thiết bị  " + self.fields["hardwareId"])
        self.device_hint.set(Path(path).name)
        self.set_status("idle", "Đối chiếu mã trên tủ, chọn cổng USB rồi nhập Wi-Fi.", "Đã đọc cấu hình")
        self.refresh_form()

    def refresh_ports(self):
        selected = self.port.get()
        ports = sorted(port.device for port in comports())
        self.port.configure(values=ports)
        self.port.set(selected if selected in ports else ports[0] if len(ports) == 1 else "")
        self.refresh_steps()
        if not ports:
            self.set_status("idle", "Cắm ESP32 rồi bấm Tìm lại cổng.", "Chưa thấy cổng USB")
        elif selected not in ports or self.status_title.get() == "Chưa thấy cổng USB":
            self.set_status("idle", "Chọn cấu hình của tủ và nhập Wi-Fi trước khi nạp.", "Đã tìm thấy cổng USB")
            self.refresh_form()

    def start_flash(self):
        if self.running:
            return
        if not self.port.get() or not self.fields:
            self.set_status("error", "Chọn cổng USB và tệp config.local.h trước khi nạp.")
            return
        try:
            image = configuration_image(self.fields, self.ssid.get(), self.password.get())
        except ValueError as error:
            self.set_status("error", str(error))
            return
        port, hardware_id, install = self.port.get(), self.fields["hardwareId"], self.install.get()
        self.password.delete(0, tk.END)
        self.set_running(True)
        self.set_status("active", "Đang kết nối với ESP32…")

        def confirm_transfer(current, expected):
            answer = queue.Queue(maxsize=1)
            self.messages.put(("transfer", (current, expected, answer)))
            return answer.get()

        def background():
            try:
                flash(port, hardware_id, image, install, self.bundle,
                      lambda status: self.messages.put(("active", status)), confirm_transfer)
                self.messages.put(("success", "Journal giữ nguyên. Kiểm tra tủ Online trên web."))
            except ValueError as error:
                self.messages.put(("error", str(error)))
            except Exception:
                self.messages.put(("error", "Nạp USB chưa hoàn tất. Kiểm tra cáp, cổng COM và thử lại."))

        threading.Thread(target=background, daemon=True).start()

    def set_running(self, running):
        self.running = running
        for widget in (self.pick, self.scan, self.ssid, self.password, self.include_firmware, self.start):
            widget.configure(state="disabled" if running else "normal")
        self.port.configure(state="disabled" if running else "readonly")
        self.start.configure(text="Đang nạp…" if running else "Nạp ESP32")
        if running:
            self.progress.grid()
            self.progress.start(16)
        else:
            self.progress.stop()
            self.progress.grid_remove()

    def poll(self):
        while not self.messages.empty():
            tone, status = self.messages.get_nowait()
            if tone == "transfer":
                current, expected, answer = status
                approved = False
                try:
                    approved = messagebox.askyesno(
                        "Chuyển bo sang tủ khác",
                        f"Chuyển bo từ {current} sang {expected}?\n\n"
                        "App sẽ thay cấu hình thiết bị và kiểm tra checksum journal sau khi nạp.",
                        parent=self, default=messagebox.NO,
                    )
                finally:
                    answer.put(approved)
                continue
            if tone in ("success", "error"):
                self.set_running(False)
            self.set_status(tone, status)
        self.after(120, self.poll)

def main():
    bundle = read_bundle(bundle_path())
    if "--self-test" in sys.argv:
        return
    root = tk.Tk()
    root.title("FloraBot ESP32 USB")
    root.minsize(850, 590)
    root.geometry("1030x620")
    ProvisioningApp(root, bundle)
    root.mainloop()


if __name__ == "__main__":
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    if sys.stderr is None:
        sys.stderr = sys.stdout
    main()
